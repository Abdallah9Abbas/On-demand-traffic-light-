/*
 * led.c
 *
 * Created: 22/02/2023 10:38:52 PM
 *  Author: Abdallah Abbas
 */ 
#include "led.h"
bool LED_init(uint8_t ledPort, uint8_t ledPin) //Output device.
{
	DIO_init(ledPin,ledPort,OUT);
	if (DIO_init(ledPin,ledPort,OUT))
	{
		return OKK;
	}
	return ERROR;
}
bool LED_on(uint8_t ledPort, uint8_t ledPin)
{
	DIO_write(ledPin,ledPort,HIGH);
	if (DIO_write(ledPin,ledPort,HIGH))
	{
		return OKK;
	}
	return ERROR;
}
bool LED_off(uint8_t ledPort, uint8_t ledPin)
{
	DIO_write(ledPin,ledPort,LOW);
	if (DIO_write(ledPin,ledPort,LOW))
	{
		return OKK;
	}
	return ERROR;
}
bool LED_toggle(uint8_t ledPort, uint8_t ledPin)
{
	DIO_toggle(ledPin,ledPort);
	if (DIO_toggle(ledPin,ledPort))
	{
		return OKK;
	}
	return ERROR;
}