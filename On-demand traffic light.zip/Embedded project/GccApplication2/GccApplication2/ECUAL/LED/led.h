/*
 * led.h
 *
 * Created: 22/02/2023 10:38:39 PM
 *  Author: Abdallah Abbas
 */ 

#include "../../MCAL/DIO/dio.h"
#define LED_1_PORT PORT_A
#define LED_1_PIN 4

// Car port and pins
#define CAR_PORT PORT_A
#define CAR_G_PIN 0
#define CAR_Y_PIN 1
#define CAR_R_PIN 2

// Pedestrian port and pins
#define PED_PORT PORT_B
#define PED_G_PIN 0
#define PED_Y_PIN 1
#define PED_R_PIN 2

#ifndef LED_H_
#define LED_H_
bool LED_init(uint8_t ledPort, uint8_t ledPin); //Output device.
bool LED_on(uint8_t ledPort, uint8_t ledPin); 
bool LED_off(uint8_t ledPort, uint8_t ledPin); 
bool LED_toggle(uint8_t ledPort, uint8_t ledPin); 
#endif /* LED_H_ */