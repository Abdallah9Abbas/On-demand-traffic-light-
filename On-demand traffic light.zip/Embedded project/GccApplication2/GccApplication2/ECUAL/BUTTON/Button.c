/*
 * Button.c
 *
 * Created: 23/02/2023 5:17:46 PM
 *  Author: Abdallah Abbas
 */ 
#include "Button.h"
bool BUTTON_init(uint8_t buttonPort, uint8_t buttonPin)
{
	DIO_init(buttonPin,buttonPort,IN);
	if (DIO_init(buttonPin,buttonPort,IN))
	{
		return OKK;
	}
	return ERROR;
}
bool BUTTON_READ(uint8_t buttonPort, uint8_t buttonPin, uint8_t *value)
{
	DIO_read(buttonPin,buttonPort,value);
	if (DIO_read(buttonPin,buttonPort,value))
	{
		return OKK;
	}
	return ERROR;

}