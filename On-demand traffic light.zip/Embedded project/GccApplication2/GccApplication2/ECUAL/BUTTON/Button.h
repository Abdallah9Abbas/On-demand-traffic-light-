/*
 * Button.h
 *
 * Created: 23/02/2023 5:17:35 PM
 *  Author: Abdallah Abbas
 */ 
#include "../../MCAL/DIO/dio.h"
#define BUTTON_1_PORT PORT_D
#define BUTTON_1_PIN PIN2

/*
#define LOW 0
#define HIGH 1*/


#ifndef BUTTON_H_
#define BUTTON_H_



bool BUTTON_init(uint8_t buttonPort, uint8_t buttonPin);
bool BUTTON_READ(uint8_t buttonPort, uint8_t buttonPin, uint8_t *value);
#endif /* BUTTON_H_ */