/*
 * dio.h
 *
 * Created: 22/02/2023 12:03:32 AM
 *  Author: Abdallah Abbas
 */ 

#include "../../UTILITIES/REGISTERS.h"
#include "../../UTILITIES/bitFunctions.h"
//Typedefs


#define ERROR 0
#define OKK 1
//Macros
#define PORT_A 'A'
#define PORT_B 'B'
#define PORT_C 'C'
#define PORT_D 'D'

//Directions
#define IN 0
#define OUT 1

//Values
#define LOW 0
#define HIGH 1

//Functions
#ifndef DIO_H_
#define DIO_H_
#include <stdbool.h>
bool DIO_init(uint8_t pinNumber, uint8_t portNumber, uint8_t direction); //Initialize DIO direction
bool DIO_write(uint8_t pinNumber, uint8_t portNumber, uint8_t value); //Write data to DIO
bool DIO_toggle(uint8_t pinNumber, uint8_t portNumber); // toggle DIO
bool DIO_read(uint8_t pinNumber, uint8_t portNumber, uint8_t *value); //Read DIO




#endif /* DIO_H_ */