/*
 * Timer.c
 *
 * Created: 23/02/2023 10:50:48 PM
 *  Author: Abdallah Abbas
 */ 
#include "Timer.h"


void TIMER_init(){
	TCCR0 = 0x00; //normal mode
}
void TIMER_delay(uint16_t millisec){
	uint16_t overflNo,initialTime;
	double timeMaxdelay,tickTime;
	uint32_t overFcont=0;
	//max delay 256 micro second
	//at 1MHz no prescaler
	// 256 prescaler
	tickTime = 256.0/1000.0; //ms    
	timeMaxdelay= 65.536; //ms		
	if(millisec<timeMaxdelay){
		initialTime = (timeMaxdelay-millisec)/tickTime;
		overflNo = 1;
		
		}else if(millisec == (int)timeMaxdelay){
		initialTime=0;
		overflNo=1;
		}else{
		overflNo = ceil((double)millisec/timeMaxdelay);
		initialTime = (1<<8) - ((double)millisec/tickTime)/overflNo;
		
	}
	TCNT0 = initialTime;
	TCCR0 |= (1<<2); //set 256 prescaler
	while(overFcont<overflNo){
		//busy wait
		while(readBIT(TIFR,0)==0);
		//clear overflow flag
		setBIT(TIFR,0);
		//increment counter
		overFcont++;
	}
	//Timer stop
	TCCR0 = 0x00;
}