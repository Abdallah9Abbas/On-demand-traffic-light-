/*
 * Types.h
 *
 * Created: 23/02/2023 11:35:43 PM
 *  Author: Abdallah Abbas
 */ 


#ifndef TYPES_H_
#define TYPES_H_


typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;


#endif /* TYPES_H_ */