/*
 * bitFunctions.h
 *
 * Created: 23/02/2023 11:25:05 PM
 *  Author: Abdallah Abbas
 */ 


#ifndef BITFUNCTIONS_H_
#define BITFUNCTIONS_H_

#define clearBIT(REG,pinNumber) REG&=~(1<<pinNumber)
#define setBIT(REG,pinNumber) REG|=(1<<pinNumber)
#define toggleBIT(REG,pinNumber) REG^=(1<<pinNumber)
#define readBIT(REG,pinNumber) ((REG&(1<<pinNumber))>>pinNumber)




#endif /* BITFUNCTIONS_H_ */