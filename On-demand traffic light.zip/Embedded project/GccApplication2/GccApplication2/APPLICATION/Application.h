/*
 * Application.h
 *
 * Created: 23/02/2023 10:57:21 PM
 *  Author: Abdallah Abbas
 */ 
#include "../ECUAL/LED/led.h"
#include "../ECUAL/BUTTON/Button.h"
#include "../MCAL/TIMER/Timer.h"
#include "../MCAL/INTERRUPT/interrupt.h"


#ifndef APPLICATION_H_
#define APPLICATION_H_
#define GREEN 0
#define YELLOW 1
#define RED 2
#define NORMAL 1
#define PEDESTRAIN 0




void APP_init(void);
void APP_start(void);


#endif /* APPLICATION_H_ */