/*
 * Application.c
 *
 * Created: 23/02/2023 10:57:31 PM
 *  Author: Abdallah Abbas
 */ 
#include "Application.h"

uint8_t carLED=GREEN;
uint8_t prevcarLED=YELLOW;
uint8_t nMode = NORMAL;

void APP_init(void){
	
	//Car LED initialization
	LED_init(CAR_PORT,CAR_G_PIN);
	LED_init(CAR_PORT,CAR_Y_PIN);
	LED_init(CAR_PORT,CAR_R_PIN);
	
	//Pedestrian LED initialization
	LED_init(PED_PORT,PED_G_PIN);
	LED_init(PED_PORT,PED_Y_PIN);
	LED_init(PED_PORT,PED_R_PIN);
	
	//Button initialization
	BUTTON_init(BUTTON_1_PORT,BUTTON_1_PIN);
	
	//Timer initialization
	TIMER_init();
	
	//SETUPS
	sei();
	RISING_EDGE_SETUP();
	SETUP_INT0();
}
void APP_start(void){
	uint8_t i;
	
	//if normal nMode 
	if(nMode || carLED==GREEN || carLED==YELLOW){
		if(!nMode){
			carLED=YELLOW;
		}
		
		switch(carLED){
			//Case GREEN LED
			case GREEN:
				LED_on(CAR_PORT,CAR_G_PIN);
				LED_on(PED_PORT,PED_R_PIN);
				LED_off(CAR_PORT,CAR_Y_PIN);
				LED_off(CAR_PORT,CAR_R_PIN);
				LED_off(PED_PORT,PED_G_PIN);
		
				
				for(i=0;i<50;i++){
					TIMER_delay(68);
					if(!nMode)break;//check if ISR was called
				}
				carLED=YELLOW;
				prevcarLED=GREEN;
				break;
			//Case YELLOW LED 
			case YELLOW:
				//if not nMode then we need to blink both
				
				if(!nMode){
					if(prevcarLED!=RED){
						LED_on(PED_PORT,PED_R_PIN);
						LED_on(CAR_PORT,CAR_G_PIN);
						//blink both yellow LEDS
						for(i=0;i<5;i++){
							LED_on(CAR_PORT,CAR_Y_PIN);
							LED_on(PED_PORT,PED_Y_PIN);							
							TIMER_delay(300);
							LED_off(CAR_PORT,CAR_Y_PIN);
							LED_off(PED_PORT,PED_Y_PIN);
							TIMER_delay(300);
							LED_on(CAR_PORT,CAR_Y_PIN);
							LED_on(PED_PORT,PED_Y_PIN);
							TIMER_delay(300);
						}
					}
					prevcarLED=YELLOW;//to go to Pedestrian lights logic
					carLED=RED;
					LED_off(PED_PORT,PED_G_PIN);
					LED_on(CAR_PORT,CAR_R_PIN);
					LED_on(CAR_PORT,PED_G_PIN);
				}else{
					//blink car yellow led
					for(i=0;i<5;i++){
						LED_on(CAR_PORT,CAR_Y_PIN);
						LED_on(PED_PORT,PED_Y_PIN);
						TIMER_delay(380);
						LED_off(CAR_PORT,CAR_Y_PIN);
						LED_off(PED_PORT,PED_Y_PIN);
						TIMER_delay(180);
						LED_on(CAR_PORT,CAR_Y_PIN);
						LED_on(PED_PORT,PED_Y_PIN);
						TIMER_delay(380);
						if(!nMode){
							prevcarLED=YELLOW;
							break;
						}//check if ISR was called
					}
				}
				LED_off(CAR_PORT,CAR_Y_PIN);
				LED_off(PED_PORT,PED_Y_PIN);
				//Enter next state
				if(prevcarLED==GREEN){
					carLED=RED;
					prevcarLED=YELLOW;
				}else if(prevcarLED==RED){
					carLED=GREEN;
					prevcarLED=YELLOW;
				}
				break;
			//Case RED LED
			case RED:
				LED_off(CAR_PORT,CAR_G_PIN);
				LED_off(PED_PORT,PED_R_PIN);
				LED_off(CAR_PORT,CAR_Y_PIN);
				LED_off(PED_PORT,PED_Y_PIN);
				LED_on(CAR_PORT,CAR_R_PIN);
				LED_on(PED_PORT,PED_G_PIN);
				for(i=0;i<50;i++){
					TIMER_delay(68);
					if(!nMode)break;
				}
				prevcarLED=RED;
				carLED=YELLOW;
				break;
			default:
				carLED=RED;
				prevcarLED=YELLOW;
				break;
		}
		
	}else{
		//Configure PED LEDs
		LED_on(PED_PORT,PED_G_PIN);
		LED_off(PED_PORT,PED_Y_PIN);
		LED_off(PED_PORT,PED_R_PIN);
		
		//Configure CAR LEDs
		LED_off(CAR_PORT,CAR_G_PIN);
		LED_off(CAR_PORT,CAR_Y_PIN);
		LED_on(CAR_PORT,CAR_R_PIN);
		TIMER_delay(5000);//5 sec delay
		
		//make sure car red light is off
		
		
		//blink both yellow while pedestrian green is on
		for(i=0;i<5;i++){
			LED_on(CAR_PORT,CAR_Y_PIN);
			LED_on(PED_PORT,PED_Y_PIN);
			TIMER_delay(390);
			LED_off(CAR_PORT,CAR_Y_PIN);
			LED_off(PED_PORT,PED_Y_PIN);
			TIMER_delay(190);
			LED_on(CAR_PORT,CAR_Y_PIN);
			LED_on(PED_PORT,PED_Y_PIN);
			TIMER_delay(390);
		}
		//Turn off yellow LEDs 
		LED_off(CAR_PORT,CAR_Y_PIN);
		LED_off(PED_PORT,PED_Y_PIN);
		//turn on PED red LED
		LED_off(CAR_PORT,CAR_R_PIN);
		LED_on(PED_PORT,PED_R_PIN);
		//reset nMode
		nMode=NORMAL;
		//Configure carLED variables
		carLED=GREEN;
		prevcarLED=YELLOW;
	}
	
}

ISR(EXT_INT_0){
	nMode=PEDESTRAIN;
}