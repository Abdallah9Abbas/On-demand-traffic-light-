/*
 * GccApplication2.c
 *
 * Created: 21/02/2023 10:51:57 PM
 * Author : Abdallah Abbas
 */ 

#include "APPLICATION/Application.h"
int main(void)
{
	//Initialize
	APP_init();
	
	//Main loop
	while(1){
		APP_start();
	}
}
/*
int main(void)
{
	uint8_t buttonstate;
	LED_init(LED_1_PORT,LED_1_PIN);
	BUTTON_init(BUTTON_1_PORT,BUTTON_1_PIN);
	while(1)
	{
		BUTTON_READ(BUTTON_1_PORT,BUTTON_1_PIN,&buttonstate);
		if (buttonstate == HIGH)
		{
			LED_on(LED_1_PORT,LED_1_PIN);
		}
		else if (buttonstate == LOW)
		{
			LED_off(LED_1_PORT,LED_1_PIN);
		}
	}
}*/